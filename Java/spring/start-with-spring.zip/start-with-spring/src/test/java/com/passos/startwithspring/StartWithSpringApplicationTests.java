package com.passos.startwithspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartWithSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
